"""
Chapter 2 – Blink an external LED on IO7
• Route prefix: /chapter2           (page)
• Toggles LED six times when browser calls /run_blink
• Serves its own image + audio from /static/…
"""

import time, errno, board, digitalio

# ---------------- LED setup -----------------------------------------
led = digitalio.DigitalInOut(board.IO7)
led.direction = digitalio.Direction.OUTPUT

# ---------------- Static & page -------------------------------------
with open("/templates/chapter2.html") as f:
    _BODY = f.read()

_PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
         f"Content-Length: {len(_BODY.encode())}\r\nConnection: close\r\n\r\n{_BODY}")

_STATIC = {
    b"/static/ch2_image.jpg": ("image/jpeg",  "ch2_image.jpg"),
    b"/static/ch2_audio.opus": ("audio/mpeg", "ch2_audio.opus"),  # label as mpeg for Safari
}

# --------------------------------------------------------------------
_BUF = bytearray(1024)
RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"

def _send_all(sock, data):
    if isinstance(data, str): data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try: sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in (104, 32, 128): return       # ECONNRESET, EPIPE
            if e.errno == errno.EAGAIN: time.sleep(0.003)
            else: raise

def try_handle(first: bytes, sock) -> bool:
    # 1) blink trigger
    if b"/run_blink" in first:
        _send_all(sock, RESP_204)
        _blink_led()
        return True

    # 2) static assets
    for url,(mime,fname) in _STATIC.items():
        if url in first:
            _serve_file(fname, mime, sock)
            return True

    # 3) chapter page
    if first.startswith(b"GET /chapter2 "):
        _send_all(sock, _PAGE)
        return True

    return False

# --------------------------------------------------------------------
def _blink_led():
    for _ in range(6):
        led.value = True;  time.sleep(0.4)
        led.value = False; time.sleep(0.4)

def _serve_file(fname, mime, sock):
    try:
        with open("/static/"+fname, "rb") as f:
            _send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
            while True:
                n = f.readinto(_BUF)
                if n==0: break
                _send_all(sock, _BUF[:n])
    except Exception as e:
        print(fname, "err:", e)
        _send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")
