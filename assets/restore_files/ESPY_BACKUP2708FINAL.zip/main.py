import time, errno, wifi, socketpool, supervisor
import board, neopixel, digitalio, random
import sys, busio, qmi8658c
import math # <-- Added import for math

# Wi-Fi access-point setup
wifi.radio.start_ap(ssid="ESPY-WIFI")         # open network
while wifi.radio.ipv4_address_ap is None:
    time.sleep(0.1)
HOST = str(wifi.radio.ipv4_address_ap)
print("✓  AP up at http://%s/" % HOST)

# Listening socket setup
pool = socketpool.SocketPool(wifi.radio)
server = pool.socket(pool.AF_INET, pool.SOCK_STREAM)
server.setsockopt(pool.SOL_SOCKET, pool.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", 80))
server.listen(4)                               # no settimeout → blocking
print("HTTP server listening on port 80")

# Helpers
BUF = bytearray(1024)
_ABORT_ERRS = {104, 32}                        # ECONNRESET, EPIPE

def recv_once(sock, buf):
    while True:
        try:
            return sock.recv_into(buf)
        except OSError as e:
            if e.errno == errno.EAGAIN:
                time.sleep(0.003)
            else:
                raise

def send_all(sock, data):
    if isinstance(data, str):
        data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try:
            sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in _ABORT_ERRS:
                return
            if e.errno == errno.EAGAIN:
                time.sleep(0.003)
            else:
                raise

RESP_404 = b"HTTP/1.1 404 Not Found\r\n\r\n"

# ───────────────── LED Status Bar helper ─────────────────
class LEDStatus:
    W = H = 8

    def __init__(self, pixels_getter):
        self._get_pixels = pixels_getter

    def _idx(self, x, y):
        return x * self.H + (y if x % 2 == 0 else self.H - 1 - y)

    def clear(self):
        px = self._get_pixels()
        if px:
            px.fill((0, 0, 0))
            px.show()

    def fill_color(self, color):
        px = self._get_pixels()
        if px:
            for x in range(self.W):
                for y in range(self.H):
                    px[self._idx(x, y)] = color
            px.show()

    def progress_for(self, seconds=10.0, color=(120, 0, 0)):
        px = self._get_pixels()
        if not px:
            return
        total = self.W * self.H
        step = seconds / float(total)
        for n in range(1, total + 1):
            lit = n
            i = 0
            for x in range(self.W):
                for y in range(self.H):
                    px[self._idx(x, y)] = color if i < lit else (0, 0, 0)
                    i += 1
            px.show()
            time.sleep(step)

    def fade_out(self, seconds=10.0, color=(120, 0, 0), random_order=False):
        """Start full color, then turn LEDs off one-by-one over `seconds`."""
        px = self._get_pixels()
        if not px:
            return

        # Light all first
        for x in range(self.W):
            for y in range(self.H):
                px[self._idx(x, y)] = color
        px.show()

        # Sequence of coords
        order = [(x, y) for x in range(self.W) for y in range(self.H)]
        if random_order:
            import random as _r
            _r.shuffle(order)

        total = len(order)
        step = seconds / float(total) if total else 0.0

        # Turn off one-by-one
        for (x, y) in order:
            px[self._idx(x, y)] = (0, 0, 0)
            px.show()
            time.sleep(step)


# Module for home page
class HomePage:
    def __init__(self):
        self._BODY = self._read_template("/templates/home.html")
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                     f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._PING_RESP = b"HTTP/1.1 204 No Content\r\n\r\n"
        self._STATIC = {
            b"/static/home.jpg": ("image/jpeg", "home.jpg"),
        }

    def _read_template(self, path):
        with open(path) as f:
            return f.read()

    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0:
                        break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print("home file err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    def try_handle(self, first_line: bytes, sock) -> bool:
        if first_line.startswith(b"GET /ping "):
            send_all(sock, self._PING_RESP)
            return True

        for url, (mime, fname) in self._STATIC.items():
            if url in first_line:
                self._serve_file(fname, mime, sock)
                return True

        try:
            path = first_line.split(b" ")[1]
        except Exception:
            return False

        if path in (b"/", b"/index", b"/index.html"):
            send_all(sock, self._PAGE)

            # Fade-out effect when home page is opened
            try:
                led_status.fade_out(seconds=2.0, color=(60, 0, 0), random_order=False)
            except Exception:
                pass

            try:
                sock.close()
            except Exception:
                pass
            return True

        return False

# Module for Chapter 1
class Chapter1:
    def __init__(self):
        self.W = self.H = 8
        self.BRIGHT = 0.03
        self.ON_COL = (0, 120, 30)
        self.OFF_COL = (0, 0, 0)
        self.pixels = None
        self._state = [False] * (self.W * self.H)
        self._BODY = self._read_template("/templates/chapter1.html")
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                     f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"
        self._STATIC = {
            b"/image.jpg": ("image/jpeg", "image.jpg"),
            b"/static/audio.opus": ("audio/ogg", "audio.opus"),
        }
        self.ROUTE_PREFIX = b"/chapter1"

    def _read_template(self, path):
        with open(path) as f:
            return f.read()

    def _init_pixels(self):
        if self.pixels is None:
            self.pixels = neopixel.NeoPixel(board.NEOPIXEL, self.W * self.H,
                                            brightness=self.BRIGHT, auto_write=False,
                                            pixel_order=neopixel.GRB)
            self._startup_twirl()
    def _init_pixels_no_twirl(self):
        if self.pixels is None:
            self.pixels = neopixel.NeoPixel(
                board.NEOPIXEL, self.W * self.H,
                brightness=self.BRIGHT, auto_write=False,
                pixel_order=neopixel.GRB
            )

    def clear_all(self):
        self._init_pixels_no_twirl()
        self.pixels.fill(self.OFF_COL)
        self.pixels.show()

    def _idx(self, x, y):
        return x * self.H + (y if x % 2 == 0 else self.H - 1 - y)

    def _toggle_xy(self, x, y):
        self._init_pixels()
        if 0 <= x < self.W and 0 <= y < self.H:
            i = self._idx(x, y)
            self._state[i] = not self._state[i]
            self.pixels[i] = self.ON_COL if self._state[i] else self.OFF_COL
            self.pixels.show()

    def _startup_twirl(self):
        self.pixels.fill(self.ON_COL)
        self.pixels.show()
        time.sleep(0.3)
        l, t, r, b = 0, 0, self.W - 1, self.H - 1
        while l <= r and t <= b:
            for x in range(l, r + 1):
                self._toggle_xy(x, t)
            for y in range(t + 1, b + 1):
                self._toggle_xy(r, y)
            if t != b:
                for x in range(r - 1, l - 1, -1):
                    self._toggle_xy(x, b)
            if l != r:
                for y in range(b - 1, t, -1):
                    self._toggle_xy(l, y)
            l += 1
            t += 1
            r -= 1
            b -= 1

    def _handle_toggle(self, first_line, sock):
        try:
            path = first_line[7:first_line.find(b" ", 7)]
            x_str, y_str = path.split(b"/")
            self._toggle_xy(int(x_str), int(y_str))
        except Exception as e:
            print("bad toggle:", e)
        send_all(sock, self._RESP_204)

    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0:
                        break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    def try_handle(self, first_line: bytes, sock) -> bool:
        if first_line.startswith(b"GET " + self.ROUTE_PREFIX + b" "):
            try:
                self.clear_all()     # LEDs off when Chapter 1 opens
            except Exception:
                pass
            send_all(sock, self._PAGE)
            return True
        for url, (mime, name) in self._STATIC.items():
            if url in first_line:
                self._serve_file(name, mime, sock)
                return True
        if first_line.startswith(b"GET " + self.ROUTE_PREFIX + b" "):
            send_all(sock, self._PAGE)
            return True
        return False

# Module for Chapter 2
class Chapter2:
    def __init__(self):
        self.led = digitalio.DigitalInOut(board.IO7)
        self.led.direction = digitalio.Direction.OUTPUT
        self._BODY = self._read_template("/templates/chapter2.html")
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                     f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._STATIC = {
            b"/static/ch2_image.jpg": ("image/jpeg", "ch2_image.jpg"),
            b"/static/ch2_audio.opus": ("audio/mpeg", "ch2_audio.opus"),
        }
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"

    def _read_template(self, path):
        with open(path) as f:
            return f.read()

    def _blink_led(self):
        for _ in range(6):
            self.led.value = True
            time.sleep(0.4)
            self.led.value = False
            time.sleep(0.4)

    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0:
                        break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    def try_handle(self, first: bytes, sock) -> bool:
        if b"/run_blink" in first:
            send_all(sock, self._RESP_204)
            self._blink_led()
            return True
        for url, (mime, fname) in self._STATIC.items():
            if url in first:
                self._serve_file(fname, mime, sock)
                return True
        if first.startswith(b"GET /chapter2 "):
            send_all(sock, self._PAGE)
            return True
        return False

# Module for Chapter 3
class Chapter3:
    def __init__(self):
        self.WIDTH = self.HEIGHT = 8
        self.BRIGHT = 0.05
        self.pixels = neopixel.NeoPixel(board.NEOPIXEL, self.WIDTH * self.HEIGHT,
                                        brightness=self.BRIGHT, auto_write=False)
        self._BODY = self._read_template("/templates/chapter3.html")
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                     f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._STATIC = {
            b"/static/ch3_image.jpg": ("image/jpeg", "ch3_image.jpg"),
            b"/static/ch3_audio.opus": ("audio/mpeg", "ch3_audio.opus"),
        }
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"

    def _read_template(self, path):
        with open(path) as f:
            return f.read()

    def index(self, x, y):
        return x * self.HEIGHT + (y if x % 2 == 0 else self.HEIGHT - 1 - y)

    def clear(self):
        self.pixels.fill((0, 0, 0))
        self.pixels.show()

    def light_specific_leds(self):
        leds = [(0, 0), (0, 1), (1, 1), (5, 5), (7, 7)]
        for x, y in leds:
            self.clear()
            self.pixels[self.index(x, y)] = (0, 255, 0)
            self.pixels.show()
            time.sleep(1)
            self.clear()
            time.sleep(0.5)
        self.clear()
        time.sleep(0.5)

    def fast_scan(self):
        self.clear()
        for _ in range(2):
            for y in range(self.HEIGHT):
                for x in range(self.WIDTH):
                    self.clear()
                    self.pixels[self.index(x, y)] = (255, 255, 0)
                    self.pixels.show()
                    time.sleep(0.015)
        self.clear()

    def center_flash(self):
        cx, cy = self.WIDTH // 2, self.HEIGHT // 2
        for _ in range(4):
            self.pixels[self.index(cx, cy)] = (255, 0, 0)
            self.pixels.show()
            time.sleep(0.375)
            self.pixels[self.index(cx, cy)] = (0, 0, 0)
            self.pixels.show()
            time.sleep(0.375)

    def center_color_shift(self):
        cx, cy = self.WIDTH // 2, self.HEIGHT // 2
        for i in range(30):
            r = int(255 * i / 30)
            g = 255 - r
            self.pixels[self.index(cx, cy)] = (r, g, 64)
            self.pixels.show()
            time.sleep(0.1)

    def gradual_fill(self):
        remaining = [(x, y) for y in range(self.HEIGHT) for x in range(self.WIDTH)]
        while remaining:
            x, y = remaining.pop(random.randint(0, len(remaining) - 1))
            self.pixels[self.index(x, y)] = (0, 30, 120)
            self.pixels.show()
            time.sleep(0.02)

    def swirl_out(self):
        l, t, r, b = 0, 0, self.WIDTH - 1, self.HEIGHT - 1
        colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (255, 0, 255), (0, 255, 255)]
        while l <= r and t <= b:
            for x in range(l, r + 1):
                self.pixels[self.index(x, t)] = random.choice(colors)
                self.pixels.show()
                time.sleep(0.02)
            for y in range(t + 1, b + 1):
                self.pixels[self.index(r, y)] = random.choice(colors)
                self.pixels.show()
                time.sleep(0.02)
            if t != b:
                for x in range(r - 1, l - 1, -1):
                    self.pixels[self.index(x, b)] = random.choice(colors)
                    self.pixels.show()
                    time.sleep(0.02)
            if l != r:
                for y in range(b - 1, t, -1):
                    self.pixels[self.index(l, y)] = random.choice(colors)
                    self.pixels.show()
                    time.sleep(0.02)
            l += 1
            t += 1
            r -= 1
            b -= 1

    def draw_smiley_face(self):
        self.clear()
        pattern = [
            [2, 3, 4, 5], [1, 6], [0, 2, 5, 7], [0, 7],
            [0, 2, 5, 7], [0, 3, 4, 7], [1, 6], [2, 3, 4, 5]
        ]
        for y, row in enumerate(pattern):
            for x in row:
                self.pixels[self.index(x, y)] = (255, 255, 0)
        self.pixels.show()

    def run_animations(self):
        for _ in range(1):
            self.light_specific_leds()
            time.sleep(0.6)
            self.center_flash()
            time.sleep(0.6)
            self.center_color_shift()
            time.sleep(0.6)
            self.fast_scan()
            time.sleep(0.6)
            self.gradual_fill()
            time.sleep(0.6)
            self.swirl_out()
            time.sleep(0.6)
            self.draw_smiley_face()
            time.sleep(1.5)
        self.clear()

    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0:
                        break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    def try_handle(self, first: bytes, sock) -> bool:
        if b"/run_animations" in first:
            send_all(sock, self._RESP_204)
            self.run_animations()
            return True
        for url, (mime, fname) in self._STATIC.items():
            if url in first:
                self._serve_file(fname, mime, sock)
                return True
        if first.startswith(b"GET /chapter3 "):
            send_all(sock, self._PAGE)
            return True
        return False

# ─────────────────────── Chapter 4 ─ Gravity‑controlled dot (Enhanced Physics) ──────────────────
class Chapter4:
    WIDTH = HEIGHT = 8
    BRIGHT = 0.05
    DOT_COLOR = 0x00FF00          # green (using single integer for PixelFramebuffer)
    # SCALE removed, using physics parameters instead
    # ACCEL_SCALE = 18.0 / 9.8    # Moved inside __init__ for clarity
    FRICTION    = 0.1             # proportional velocity damping per second
    REST_COEFF  = 0.0             # bounce restitution
    MAX_DT      = 0.1             # cap ∆t

    def __init__(self):
        # Re‑use Chapter 1’s or Chapter 3's NeoPixel strip if it exists; else create our own.
        # Note: PixelFramebuffer requires specific setup, so we'll manage it here.
        self.pixels = None
        self.fb = None # Will hold the PixelFramebuffer instance
        self._ensure_strip_and_framebuffer()

        # IMU setup (QMI8658C on IMU_SCL / IMU_SDA)
        self.i2c = busio.I2C(board.IMU_SCL, board.IMU_SDA)
        while not self.i2c.try_lock(): pass
        self.i2c.unlock()
        # Assuming default address 0x6B as in the good program, adjust if needed
        self.imu = qmi8658c.QMI8658C(self.i2c, address=0x6B)

        # Physics state variables
        self.x, self.y   = 4.0, 4.0              # position in pixel coordinates (float)
        self.vx, self.vy = 0.0, 0.0              # velocity in pixels per second
        self.t_prev = time.monotonic()           # Initialize previous time

        # Load template and static map
        try:
            with open("/templates/chapter4.html") as f:
                self._BODY = f.read()
        except Exception as e:
            print("Error reading chapter4.html:", e)
            self._BODY = "<html><body><h1>Chapter 4</h1><p>Error loading page.</p></body></html>"

        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                      f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._STATIC = {
            b"/static/ch4_image.jpg":  ("image/jpeg",  "ch4_image.jpg"),
            b"/static/ch4_audio.opus": ("audio/mpeg",  "ch4_audio.opus"),
        }
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"
        self._running = False
        self._stop = False

    # ---------- hardware helpers ----------
    def _ensure_strip_and_framebuffer(self):
        if self.pixels and self.fb:
            return
        # 1) Check if Chapter 3 strip is available (preferred as it's initialized early)
        if 'chapter3' in globals() and getattr(chapter3, 'pixels', None):
            print("Reusing Chapter 3 NeoPixel strip for Chapter 4")
            # Important: Disable auto_write for compatibility with PixelFramebuffer
            chapter3.pixels.auto_write = False
            chapter3.pixels.brightness = self.BRIGHT # Set brightness
            self.pixels = chapter3.pixels
        # 2) Check if Chapter 1 strip is available
        elif 'chapter1' in globals() and getattr(chapter1, 'pixels', None):
            print("Reusing Chapter 1 NeoPixel strip for Chapter 4")
            # Important: Disable auto_write for compatibility with PixelFramebuffer
            chapter1.pixels.auto_write = False
            chapter1.pixels.brightness = self.BRIGHT # Set brightness
            self.pixels = chapter1.pixels
        # 3) Create our own strip if none exist
        else:
            print("Creating new NeoPixel strip for Chapter 4")
            self.pixels = neopixel.NeoPixel(
                board.NEOPIXEL,
                self.WIDTH * self.HEIGHT,
                brightness=self.BRIGHT,
                auto_write=False, # Must be False for PixelFramebuffer
                pixel_order=neopixel.RGB # Match the good program's order
            )

        # Create the PixelFramebuffer instance
        try:
            # Import here to avoid issues if adafruit_pixel_framebuf isn't always needed/available elsewhere
            from adafruit_pixel_framebuf import PixelFramebuffer, VERTICAL
            self.fb = PixelFramebuffer(
                self.pixels,
                self.WIDTH,
                self.HEIGHT,
                orientation=VERTICAL,
                alternating=False, # Match the good program's layout
                reverse_x=False,
                reverse_y=True
            )
            print("PixelFramebuffer initialized for Chapter 4")
        except ImportError as e:
            print("Error importing adafruit_pixel_framebuf:", e)
            print("Chapter 4 animation will not work correctly.")
            self.fb = None # Disable drawing if framebuffer fails
        except Exception as e:
             print("Error initializing PixelFramebuffer:", e)
             self.fb = None


    # def _idx(self, x, y): # Not needed anymore with PixelFramebuffer
    #     return y*self.WIDTH + (x if y % 2 == 0 else self.WIDTH-1-x)

    # def _clear(self): # Not needed anymore, fb.fill(0) handles clearing
    #     self.pixels.fill((0,0,0))
    #     self.pixels.show()

    # def _accel_to_xy(self, ax, ay): # Not needed anymore, physics handles position
    #     x = int(4 + ax*self.SCALE/9.8)
    #     y = int(4 + ay*self.SCALE/9.8)
    #     return max(0,min(7,x)), max(0,min(7,y))

    # ---------- demo loop ----------
    def _run_dotmove(self, max_seconds=30): # Increased default duration
        if self._running or not self.fb or not self.pixels:
            print("Chapter 4: Cannot start animation. Already running or resources not available.")
            return
        self._running, self._stop = True, False
        print("Chapter 4: Starting enhanced dot movement animation.")

        # Reset physics state for a fresh start each time
        self.x, self.y   = 4.0, 4.0
        self.vx, self.vy = 0.0, 0.0
        self.t_prev = time.monotonic()
        ACCEL_SCALE = 18.0 / 9.8 # Define locally for clarity

        t0 = time.monotonic()
        try:
            while not self._stop and (time.monotonic()-t0) < max_seconds:
                # ----- time step -----
                t_now = time.monotonic()
                dt = min(t_now - self.t_prev, self.MAX_DT)
                self.t_prev = t_now

                if dt <= 0: # Prevent division by zero or negative time steps
                    dt = 0.01 # Use a small default if needed
                    time.sleep(0.01)
                    continue

                # ----- read accelerometer -----
                try:
                    ax, ay, _ = self.imu.acceleration          # m s-2
                except Exception as e:
                    print("Chapter 4: IMU read error:", e)
                    time.sleep(0.1)
                    continue

                # map:  +ax tilt → move right, +ay tilt → move down
                ax_pix =  ax * ACCEL_SCALE            # pixels / s²
                ay_pix =  ay * ACCEL_SCALE

                # ----- semi-implicit Euler integration -----
                self.vx += ax_pix * dt
                self.vy += ay_pix * dt
                # apply simple friction
                self.vx *= 1.0 - self.FRICTION * dt
                self.vy *= 1.0 - self.FRICTION * dt
                self.x  += self.vx * dt
                self.y  += self.vy * dt

                # ----- boundary collisions with bounce -----
                if self.x < 0:
                    self.x, self.vx = 0, -self.vx * self.REST_COEFF
                elif self.x > self.WIDTH - 1:
                    self.x, self.vx = self.WIDTH - 1, -self.vx * self.REST_COEFF
                if self.y < 0:
                    self.y, self.vy = 0, -self.vy * self.REST_COEFF
                elif self.y > self.HEIGHT - 1:
                    self.y, self.vy = self.HEIGHT - 1, -self.vy * self.REST_COEFF

                # ----- draw -----
                self.fb.fill(0) # Clear the framebuffer
                # Ensure coordinates are within bounds before drawing
                draw_x = max(0, min(self.WIDTH - 1, round(self.x)))
                draw_y = max(0, min(self.HEIGHT - 1, round(self.y)))
                self.fb.pixel(draw_x, draw_y, self.DOT_COLOR)
                self.fb.display() # Update the physical LEDs

                time.sleep(0.02)           # ≈50 fps refresh

        except Exception as e:
            print("Chapter 4: Animation loop error:", e)
        finally:
            # Ensure cleanup happens
            if self.fb:
                self.fb.fill(0)
                self.fb.display()
            print("Chapter 4: Stopping enhanced dot movement animation.")
            self._running = False
            self._stop = False # Reset stop flag for next run

    # ---------- static file helper ----------
    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/"+fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n") # Fixed \r\n
                while True:
                    n = f.readinto(BUF)
                    if n == 0: break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    # ---------- public dispatcher ----------
    def try_handle(self, first: bytes, sock) -> bool:
        if b"/stop_dot" in first:
            self._stop = True
            send_all(sock, self._RESP_204)
            return True
        if b"/run_dotmove" in first:
            send_all(sock, self._RESP_204)
            # Run the animation in a separate thread or task if possible,
            # otherwise, it will block the main server loop.
            # For simplicity here, it runs directly, blocking the server until done or stopped.
            # Consider using asyncio or threading for non-blocking behavior in a more complex server.
            self._run_dotmove()
            return True
        for url, (mime, fname) in self._STATIC.items():
            if url in first:
                self._serve_file(fname, mime, sock)
                return True
        if first.startswith(b"GET /chapter4 "):
            send_all(sock, self._PAGE)
            return True
        return False

# ─────────────────────── Chapter 5 ─ scroll hello ─────────────
# ─────────────────────── Chapter 5 ─ scroll hello (per-letter colors) ─────────────
class Chapter5:
    WIDTH = HEIGHT = 8
    BRIGHTNESS = 0.12
    SCROLL_DELAY = 0.08
    MESSAGE = "  HELLO   "
    CHAR_W = 6

    # Leave True if your hardware shows green when you ask for red (R/G swapped).
    SWAP_RG = True

    # Color constants (0xRRGGBB)
    GREEN  = 0x00FF00
    RED    = 0xFF0000
    YELLOW = 0xFFFF00
    PURPLE = 0x800080   # use 0xFF00FF for brighter magenta

    def __init__(self):
        # Reuse an existing NeoPixel object; only create if none exists
        if 'chapter4' in globals() and getattr(chapter4, 'pixels', None):
            self.pixels = chapter4.pixels
        elif 'chapter3' in globals() and getattr(chapter3, 'pixels', None):
            self.pixels = chapter3.pixels
        else:
            self.pixels = neopixel.NeoPixel(
                board.NEOPIXEL,
                self.WIDTH * self.HEIGHT,
                auto_write=False,
                brightness=self.BRIGHTNESS,
                pixel_order=neopixel.RGB
            )

        try:
            self.pixels.auto_write = False
            self.pixels.brightness = self.BRIGHTNESS
        except AttributeError:
            pass

        from adafruit_pixel_framebuf import PixelFramebuffer, VERTICAL
        self.fb = PixelFramebuffer(
            self.pixels, self.WIDTH, self.HEIGHT,
            orientation=VERTICAL,
            alternating=False,
            reverse_x=False,
            reverse_y=True
        )

        self._BODY = self._read_template("/templates/chapter5.html")
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                      f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._STATIC = {
            b"/static/ch5_image.jpg": ("image/jpeg", "ch5_image.jpg"),
            b"/static/ch5_audio.opus": ("audio/mpeg", "ch5_audio.opus"),
        }
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"

    # ----- helpers -----
    def _read_template(self, path):
        with open(path) as f:
            return f.read()

    def _c(self, color):  # optional R<->G swap to correct red/green inversion
        if not self.SWAP_RG:
            return color
        r = (color >> 16) & 0xFF
        g = (color >> 8)  & 0xFF
        b =  color         & 0xFF
        return (g << 16) | (r << 8) | b

    # ----- drawing -----
    def _display_letter(self, letter, color):
        self.fb.fill(0x000000)
        self.fb.text(letter, 1, 0, self._c(color))  # y=0 to avoid clipping on 8x8
        self.fb.display()
        time.sleep(1.0)

    def _scroll_text(self, text, color):
        text_width = len(text) * self.CHAR_W
        for offset in range(self.WIDTH + text_width + 1):
            self.fb.fill(0x000000)
            x = self.WIDTH - offset
            self.fb.text(text, x, 0, self._c(color))
            self.fb.display()
            time.sleep(self.SCROLL_DELAY)

    def run_sequence(self):
        # quick smoke test (visible blink)
        self.fb.fill(self._c(0x202020)); self.fb.display(); time.sleep(0.2)
        self.fb.fill(0x000000); self.fb.display(); time.sleep(0.1)

        # A (green), B (red), C (yellow)
        self._display_letter("A", self.GREEN)
        self._display_letter("B", self.RED)
        self._display_letter("C", self.YELLOW)

        # clear then scroll HELLO in purple
        self.fb.fill(0x000000); self.fb.display()
        self._scroll_text(self.MESSAGE, self.PURPLE)

    # ----- HTTP/file -----
    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0:
                        break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    def try_handle(self, first: bytes, sock) -> bool:
        if b"/run_sequence" in first:
            print("CH5: /run_sequence requested")
            send_all(sock, self._RESP_204)
            try:
                sock.close()
            except Exception:
                pass
            self.run_sequence()
            return True
        for url, (mime, fname) in self._STATIC.items():
            if url in first:
                self._serve_file(fname, mime, sock)
                return True
        if first.startswith(b"GET /chapter5 "):
            send_all(sock, self._PAGE)
            return True
        return False



# ─────────────────────── Chapter 6 ─ Tilt‑Tetris ─────────────


# ─────────────────────── Chapter 6 ─ Tilt-Tetris ─────────────
class Chapter6:
    WIDTH = HEIGHT = 8
    BRIGHT = 0.02   # valeur "neutre" (on ne s'y fie plus)
    COLOR_SCALE = 0.15  # coefficient logiciel pour réduire la luminosité

    # Tetris parameters
    BASE_DROP_MS      = 1000
    MOVE_THRESHOLD    =  2.0
    HORIZ_DELAY_MS    = 180
    TAP_THRESHOLD     =  3.0
    TAP_DELAY_MS      = 300

    # Couleurs brutes
    BASE_COLORS = [
        0xFF0000,  # rouge
        0xFF7F00,  # orange
        0xFFFF00,  # jaune
        0x00FF00,  # vert
        0x0000FF,  # bleu
        0x4B0082,  # indigo
        0x9400D3   # violet
    ]

    @staticmethod
    def _dim(color, s=0.06):
        """Réduit l’intensité d’une couleur 0xRRGGBB par un facteur s."""
        r = (color >> 16) & 0xFF
        g = (color >> 8)  & 0xFF
        b =  color        & 0xFF
        r = int(r * s); g = int(g * s); b = int(b * s)
        if r < 0: r = 0
        if g < 0: g = 0
        if b < 0: b = 0
        return (r << 16) | (g << 8) | b

    # Pièces Tetris
    SHAPES = (
        ((1,1,1),(0,0,0),(0,0,0)),
        ((1,1,1),(0,1,0),(0,0,0)),
        ((1,1,0),(0,1,1),(0,0,0)),
        ((1,0,0),(1,1,1),(0,0,0)),
        ((1,1,0),(1,1,0),(0,0,0)),
        ((0,1,1),(1,1,0),(0,0,0)),
        ((0,0,1),(1,1,1),(0,0,0)),
    )

    def __init__(self):
        self.pixels, self.fb = None, None
        self.imu = None
        self._ensure_strip_and_framebuffer()
        self._ensure_imu()

        # Palette dimmée
        self.COLORS = [self._dim(c, self.COLOR_SCALE) for c in self.BASE_COLORS]

        # Web page & assets
        try:
            with open("/templates/chapter6.html") as f:
                self._BODY = f.read()
        except Exception as e:
            print("Chapter6: template missing, using fallback:", e)
            self._BODY = "<html><body><h1>Chapter 6: Tilt-Tetris</h1><p>Use /run_tetris to start.</p></body></html>"
        self._PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                      f"Content-Length: {len(self._BODY.encode())}\r\nConnection: close\r\n\r\n{self._BODY}")
        self._STATIC = {
            b"/static/ch6_image.jpg": ("image/jpeg", "ch6_image.jpg"),
            b"/static/ch6_audio.opus": ("audio/ogg", "ch6_audio.opus"),
        }
        self._RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"

        self._running = False
        self._stop = False
        self._init_state()

    # ---------- hardware ----------
    def _ensure_strip_and_framebuffer(self):
        if self.pixels and self.fb:
            return
        if 'chapter4' in globals() and getattr(chapter4, 'pixels', None):
            self.pixels = chapter4.pixels
        elif 'chapter3' in globals() and getattr(chapter3, 'pixels', None):
            self.pixels = chapter3.pixels
        elif 'chapter1' in globals() and getattr(chapter1, 'pixels', None):
            self.pixels = chapter1.pixels
        else:
            self.pixels = neopixel.NeoPixel(
                board.NEOPIXEL, self.WIDTH * self.HEIGHT,
                brightness=self.BRIGHT, auto_write=False, pixel_order=neopixel.RGB
            )
        try:
            self.pixels.auto_write = False
            self.pixels.brightness = self.BRIGHT
        except AttributeError:
            pass

        from adafruit_pixel_framebuf import PixelFramebuffer, VERTICAL
        self.fb = PixelFramebuffer(
            self.pixels, self.WIDTH, self.HEIGHT,
            orientation=VERTICAL, alternating=False,
            reverse_x=False, reverse_y=True
        )
        print("Chapter6: PixelFramebuffer ready.")

    def _ensure_imu(self):
        if 'chapter4' in globals() and getattr(chapter4, 'imu', None):
            self.imu = chapter4.imu
            return
        try:
            self.i2c = busio.I2C(scl=board.IMU_SCL, sda=board.IMU_SDA)
            while not self.i2c.try_lock(): pass
            self.i2c.unlock()
            self.imu = qmi8658c.QMI8658C(self.i2c)
        except Exception as e:
            print("Chapter6: IMU init failed:", e)
            self.imu = None

    # ---------- game core ----------
    def _init_state(self):
        self.board = [[0]*self.WIDTH for _ in range(self.HEIGHT)]
        self.piece = [[0]*3 for _ in range(3)]
        self.piece_col = self.COLORS[0]
        self.px = self.WIDTH//2 - 1
        self.py = 0
        self.lines = 0

    def _spawn_piece(self):
        idx = random.randrange(len(self.SHAPES))
        self.piece = [list(row) for row in self.SHAPES[idx]]
        self.piece_col = self.COLORS[idx]
        self.px = self.WIDTH//2 - 1
        self.py = 0

    def _cell_busy(self, x, y):
        return y >= self.HEIGHT or x < 0 or x >= self.WIDTH or self.board[y][x]

    def _can_move(self, nx, ny, test=None):
        g = test or self.piece
        for r in range(3):
            for c in range(3):
                if g[r][c] and self._cell_busy(nx+c, ny+r):
                    return False
        return True

    def _merge_piece(self):
        for r in range(3):
            for c in range(3):
                if self.piece[r][c] and 0 <= self.py+r < self.HEIGHT and 0 <= self.px+c < self.WIDTH:
                    self.board[self.py+r][self.px+c] = self.piece_col

    def _clear_lines(self):
        new_rows = [row for row in self.board if not all(row)]
        cleared = self.HEIGHT - len(new_rows)
        if cleared:
            self.lines += cleared
        self.board = [[0]*self.WIDTH for _ in range(cleared)] + new_rows

    def _rotate_piece(self):
        tmp = [[self.piece[2-c][r] for c in range(3)] for r in range(3)]
        if self._can_move(self.px, self.py, tmp):
            self.piece[:] = tmp

    def _draw(self):
        self.fb.fill(0)
        for y, row in enumerate(self.board):
            for x, col in enumerate(row):
                if col:
                    self.fb.pixel(x, y, col)
        for r in range(3):
            for c in range(3):
                if self.piece[r][c]:
                    x, y = self.px + c, self.py + r
                    if 0 <= x < self.WIDTH and 0 <= y < self.HEIGHT:
                        self.fb.pixel(x, y, self.piece_col)
        self.fb.display()

    def _show_score(self):
        self.fb.fill(0)
        s = str(self.lines)
        dim_white = self._dim(0xFFFFFF, self.COLOR_SCALE*0.5)
        if len(s) == 1:
            self.fb.text(s, 3, 1, dim_white)
        else:
            self.fb.text(s[0], 0, 1, dim_white)
            self.fb.text(s[1], 4, 1, dim_white)
        self.fb.display()

    # ---------- control ----------
    def _ms(self): return time.monotonic() * 1000.0

    def run_tetris(self):
        if self._running or self.fb is None or self.pixels is None or self.imu is None:
            print("Chapter6: cannot start (busy or hardware missing).")
            return
        self._running, self._stop = True, False
        print("Chapter6: Tetris starting.")

        try:
            self._init_state()
            self._spawn_piece()
            last_drop = self._ms()
            last_move = 0.0
            last_tap  = 0.0

            while not self._stop:
                try:
                    ax, ay, az = self.imu.acceleration
                except Exception as e:
                    print("Chapter6: IMU read error:", e)
                    time.sleep(0.05)
                    continue

                now = self._ms()
                if now - last_move > self.HORIZ_DELAY_MS:
                    if ax > self.MOVE_THRESHOLD and self._can_move(self.px+1, self.py):
                        self.px += 1; last_move = now
                    elif ax < -self.MOVE_THRESHOLD and self._can_move(self.px-1, self.py):
                        self.px -= 1; last_move = now

                g_mag = math.sqrt(ax*ax + ay*ay + az*az)
                if abs(g_mag - 9.8) > self.TAP_THRESHOLD and now - last_tap > self.TAP_DELAY_MS:
                    self._rotate_piece(); last_tap = now

                if now - last_drop >= self.BASE_DROP_MS:
                    if self._can_move(self.px, self.py + 1):
                        self.py += 1
                    else:
                        self._merge_piece()
                        self._clear_lines()
                        self._spawn_piece()
                        if not self._can_move(self.px, self.py):
                            break
                    last_drop = now

                self._draw()
                time.sleep(0.02)

            self._show_score()

        except Exception as e:
            print("Chapter6: runtime error:", e)
        finally:
            self._running = False
            self._stop = False
            print("Chapter6: Tetris finished (score shown).")

    # ---------- static files ----------
    def _serve_file(self, fname, mime, sock):
        try:
            with open("/static/" + fname, "rb") as f:
                send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
                while True:
                    n = f.readinto(BUF)
                    if n == 0: break
                    send_all(sock, BUF[:n])
        except Exception as e:
            print(fname, "err:", e)
            send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

    # ---------- HTTP dispatcher ----------
    def try_handle(self, first: bytes, sock) -> bool:
        if b"/stop_tetris" in first:
            self._stop = True
            try:
                if self.fb:
                    self.fb.fill(0)
                    self.fb.display()
            except Exception:
                pass
            send_all(sock, self._RESP_204)
            return True
        if b"/run_tetris" in first:
            send_all(sock, self._RESP_204)
            self.run_tetris()
            return True
        for url, (mime, fname) in self._STATIC.items():
            if url in first:
                self._serve_file(fname, mime, sock)
                return True
        if first.startswith(b"GET /chapter6 "):
            send_all(sock, self._PAGE)
            return True
        return False
#----------------------------------------

# Instantiate modules for chapters
home_page = HomePage()
chapter1 = Chapter1()
chapter2 = Chapter2()
chapter3 = Chapter3()
chapter4 = Chapter4()
chapter5 = Chapter5()
chapter6 = Chapter6()

# LED status uses existing NeoPixel
def _status_pixels():
    if getattr(chapter3, "pixels", None):
        return chapter3.pixels
    if getattr(chapter4, "pixels", None):
        return chapter4.pixels
    if getattr(chapter1, "pixels", None):
        return chapter1.pixels
    return None

led_status = LEDStatus(_status_pixels)

# ---- BOOT VISIBILITY CHECK ----
_px = _status_pixels()
if _px is None:
    print("LEDStatus: no NeoPixel instance available at boot.")
else:
    try:
        _px.auto_write = False
        _px.brightness = 0.10
    except Exception:
        pass
    for _ in range(2):
        _px.fill((32, 32, 32)); _px.show(); time.sleep(0.25)
        _px.fill((0, 0, 0));    _px.show(); time.sleep(0.25)

    # NEW: start red, fade-out dot-by-dot over 10s
    led_status.fade_out(seconds=10.0, color=(60, 0, 0), random_order=False)

CHAPTERS = [home_page, chapter1, chapter2, chapter3, chapter4, chapter5, chapter6]
print("✓ home & chapters imported")

# Main loop
while True:
    client, _ = server.accept()
    try:
        if recv_once(client, BUF) == 0:
            client.close()
            continue
        first = bytes(BUF).split(b"\r", 1)[0]
        handled = False
        for ch in CHAPTERS:
            try:
                if ch.try_handle(first, client):
                    handled = True
                    break
            except Exception as err:
                print("‼ crash in", ch.__class__.__name__, "→", err)
                supervisor.reload()
        if not handled:
            send_all(client, RESP_404)
    except Exception as e:
        print("socket error:", e)
    finally:
        try:
            client.close()
        except Exception:
            pass