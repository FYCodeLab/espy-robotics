"""
chapter4.py – Gravity-controlled dot demo
• Page      : /chapter4               (HTML + audio + image)
• Start demo: /run_dotmove            (runs up to 15 s)
• Stop demo : /stop_dot               (immediately ends the loop)
Requires a QMI8658C IMU on I2C (IMU_SCL, IMU_SDA pins).
"""

import time, errno, sys, board, busio, neopixel
import qmi8658c                               # IMU driver in /lib

# ── Shared NeoPixel matrix (re-use Chapter 1 strip) ──────────────────
WIDTH = HEIGHT = 8
BRIGHT = 0.05
DOT_COLOR = (0, 32, 32)                      # dim cyan
pixels = None                                # we’ll fetch it lazily

def _ensure_strip():
    global pixels
    if pixels: return pixels
    if "chapters.chapter1" in sys.modules:
        ch1 = sys.modules["chapters.chapter1"]
        if not hasattr(ch1, "pixels") or ch1.pixels is None:
            if hasattr(ch1, "_init_pixels"):
                ch1._init_pixels()
        pixels = ch1.pixels
    else:
        pixels = neopixel.NeoPixel(board.NEOPIXEL, WIDTH * HEIGHT,
                                   brightness=BRIGHT, auto_write=False)
    return pixels


def _idx(x, y):
    return y * WIDTH + (x if y % 2 == 0 else WIDTH - 1 - x)

def clear():
    strip = _ensure_strip()
    strip.fill((0, 0, 0))
    strip.show()

# ── IMU setup ─────────────────────────────────────────────────────────
i2c = busio.I2C(board.IMU_SCL, board.IMU_SDA)
while not i2c.try_lock(): pass
i2c.unlock()
imu = qmi8658c.QMI8658C(i2c)

SCALE = 5
def accel_to_xy(ax, ay):
    x = int(4 + ax * SCALE / 9.8)
    y = int(4 + ay * SCALE / 9.8)
    return max(0, min(7, x)), max(0, min(7, y))

# ── Demo loop ─────────────────────────────────────────────────────────
_running = False
_stop = False

def run_dotmove(max_seconds=15):
    global _running, _stop
    if _running: return
    _running, _stop = True, False
    strip = _ensure_strip()
    t0 = time.monotonic()
    try:
        while not _stop and (time.monotonic() - t0) < max_seconds:
            ax, ay, _ = imu.acceleration
            x, y = accel_to_xy(ax, ay)
            strip.fill((0, 0, 0))
            strip[_idx(x, y)] = DOT_COLOR
            strip.show()
            time.sleep(0.05)
    finally:
        strip.fill((0, 0, 0))
        strip.show()
        _running = False

# ── HTTP assets ───────────────────────────────────────────────────────
with open("/templates/chapter4.html") as f:
    _BODY = f.read()

_PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
         f"Content-Length: {len(_BODY.encode())}\r\nConnection: close\r\n\r\n{_BODY}")

_STATIC = {
    b"/static/ch4_image.jpg":  ("image/jpeg",  "ch4_image.jpg"),
    b"/static/ch4_audio.opus": ("audio/mpeg",  "ch4_audio.opus"),
}

_BUF = bytearray(1024)
_RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"
_ABORT_ERRS = {104, 32, 128}

def _send_all(sock, data):
    if isinstance(data, str): data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try: sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in _ABORT_ERRS: return
            if e.errno == errno.EAGAIN: time.sleep(0.003)
            else: raise

def _serve_file(fname, mime, sock):
    try:
        with open("/static/" + fname, "rb") as f:
            _send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
            while True:
                n = f.readinto(_BUF)
                if n == 0: break
                _send_all(sock, _BUF[:n])
    except Exception as e:
        print(fname, "err:", e)
        _send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")

# ── Public entry point for main.py ────────────────────────────────────

def try_handle(self, first: bytes, sock) -> bool:
    # --- STOP: stop loop + clear immediately ---
    if b"/stop_tetris" in first:
        self._stop = True
        send_all(sock, self._RESP_204)
        try:
            if self.fb:
                self.fb.fill(0)
                self.fb.display()
        except Exception as e:
            print("Chapter6: clear-on-stop err:", e)
        return True

    # --- RUN: free the HTTP client, then run blocking ---
    if b"/run_tetris" in first:
        send_all(sock, self._RESP_204)
        try:
            sock.close()  # libère la requête fetch immédiatement
        except Exception:
            pass

        # (Ré)assure le framebuffer
        if not self.fb or not self.pixels:
            self._ensure_strip_and_framebuffer()

        # petit clear de sécurité
        try:
            self.fb.fill(0)
            self.fb.display()
        except Exception:
            pass

        self.run_tetris()  # bloque le thread serveur tant que le jeu tourne
        return True

    # --- static files ---
    for url, (mime, fname) in self._STATIC.items():
        if url in first:
            self._serve_file(fname, mime, sock)
            return True

    # --- page /chapter6: noir au chargement
    if first.startswith(b"GET /chapter6 "):
        try:
            led_status.clear()
        except Exception:
            pass
        send_all(sock, self._PAGE)
        return True

    return False
