"""
Chapter 1 – NeoPixel drawing board + audio guide
Safe on minimal CircuitPython builds.
"""

import time, errno, board, neopixel


# ── NeoPixel 8 × 8 ───────────────────────────────────────────────────
W = H = 8
BRIGHT = 0.03
ON_COL  = (0, 120, 30)
OFF_COL = (0, 0, 0)

pixels = None                    # lazy-created
_state = [False]*(W*H)

def _init_pixels():
    global pixels
    if pixels is None:
        pixels = neopixel.NeoPixel(board.NEOPIXEL, W*H,
                                   brightness=BRIGHT, auto_write=False)
        _startup_twirl()

def _idx(x, y): return x * H + (y if x % 2 == 0 else H - 1 - y)


def _toggle_xy(x, y):
    _init_pixels()
    if 0<=x<W and 0<=y<H:
        i = _idx(x, y)
        _state[i] = not _state[i]
        pixels[i] = ON_COL if _state[i] else OFF_COL
        pixels.show()

def _startup_twirl():
    pixels.fill(ON_COL); pixels.show(); time.sleep(0.3)
    l,t,r,b = 0,0,W-1,H-1
    while l<=r and t<=b:
        for x in range(l, r+1): _toggle_xy(x,t)
        for y in range(t+1,b+1): _toggle_xy(r,y)
        if t!=b:
            for x in range(r-1,l-1,-1): _toggle_xy(x,b)
        if l!=r:
            for y in range(b-1,t,-1): _toggle_xy(l,y)
        l+=1; t+=1; r-=1; b-=1

# ── Socket helpers ───────────────────────────────────────────────────
_RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"
_BUF      = bytearray(1024)
_ABORT_ERRS = {104, 32, 128}          # ECONNRESET, EPIPE

def _send_all(sock, data):
    if isinstance(data, str):
        data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try:
            sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in _ABORT_ERRS:   # client closed socket
                return
            if e.errno == errno.EAGAIN:
                time.sleep(0.003)
            else:
                raise

# ── HTML page ────────────────────────────────────────────────────────
with open("/templates/chapter1.html") as f:
    _BODY = f.read()

_PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
         f"Content-Length: {len(_BODY.encode())}\r\nConnection: close\r\n\r\n{_BODY}")

# ── Static files map (disk → URL) ────────────────────────────────────
_STATIC = {
    b"/image.jpg":          ("image/jpeg",  "image.jpg"),
    b"/static/audio.opus":  ("audio/mpeg",  "audio.opus"),  # label as MP3 for Safari
}

# ── Public entry point ───────────────────────────────────────────────
ROUTE_PREFIX = b"/chapter1"

def try_handle(first_line: bytes, sock) -> bool:
    # Toggle LED
    if first_line.startswith(b"GET /p/"):
        _handle_toggle(first_line, sock); return True
    # Static
    for url,(mime,name) in _STATIC.items():
        if url in first_line:
            _serve_file(name, mime, sock); return True
    # Page
    if first_line.startswith(b"GET " + ROUTE_PREFIX + b" "):
   
        _send_all(sock, _PAGE); return True
    return False

# ── Internal helpers ────────────────────────────────────────────────
def _handle_toggle(first_line, sock):
    try:
        path = first_line[7:first_line.find(b" ",7)]
        x_str,y_str = path.split(b"/")
        _toggle_xy(int(x_str), int(y_str))
    except Exception as e:
        print("bad toggle:", e)
    _send_all(sock, _RESP_204)

def _serve_file(fname, mime, sock):
    try:
        with open("/static/"+fname, "rb") as f:
            _send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
            while True:
                n = f.readinto(_BUF)
                if n==0: break
                _send_all(sock, _BUF[:n])
    except Exception as e:
        print(fname, "err:", e)
        _send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")
