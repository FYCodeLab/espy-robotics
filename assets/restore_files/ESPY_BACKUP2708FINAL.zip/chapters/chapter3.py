"""
Chapter 3 – LED-matrix animation show
• Page      : /chapter3
• Start show: /run_animations
• Assets    : /static/ch3_image.jpg  /static/ch3_audio.opus
"""

import time, errno, random, board, neopixel

# ---------- NeoPixel matrix -----------------------------------------
WIDTH = HEIGHT = 8                 # <— keep one set of names
BRIGHT = 0.05
pixels = neopixel.NeoPixel(board.NEOPIXEL, WIDTH * HEIGHT,
                           brightness=BRIGHT, auto_write=False)

def index(x, y):                   # column-serpentine wiring
    return x * HEIGHT + (y if x % 2 == 0 else HEIGHT - 1 - y)

def clear():
    pixels.fill((0, 0, 0))
    pixels.show()

# ---------- animation helpers ---------------------------------------
def light_specific_leds():
    leds = [(0, 0), (0, 1), (1, 1), (5, 5), (7, 7)]
    for x, y in leds:
        clear()
        pixels[index(x, y)] = (0, 255, 0)
        pixels.show()
        time.sleep(1)
        clear()
        time.sleep(0.5)
    clear(); time.sleep(0.5)

def fast_scan():
    clear()
    for _ in range(2):
        for y in range(HEIGHT):
            for x in range(WIDTH):
                clear()
                pixels[index(x, y)] = (255, 255, 0)
                pixels.show()
                time.sleep(0.015)
    clear()

def center_flash():
    cx, cy = WIDTH // 2, HEIGHT // 2
    for _ in range(4):
        pixels[index(cx, cy)] = (255, 0, 0)
        pixels.show(); time.sleep(0.375)
        pixels[index(cx, cy)] = (0, 0, 0)
        pixels.show(); time.sleep(0.375)

def center_color_shift():
    cx, cy = WIDTH // 2, HEIGHT // 2
    for i in range(30):
        r = int(255 * i / 30)
        g = 255 - r
        pixels[index(cx, cy)] = (r, g, 64)
        pixels.show(); time.sleep(0.1)

def gradual_fill():
    remaining = [(x, y) for y in range(HEIGHT) for x in range(WIDTH)]
    while remaining:
        x, y = remaining.pop(random.randint(0, len(remaining) - 1))
        pixels[index(x, y)] = (0, 30, 120)
        pixels.show(); time.sleep(0.02)

def swirl_out():
    l, t, r, b = 0, 0, WIDTH - 1, HEIGHT - 1
    colors = [(255,0,0),(0,255,0),(0,0,255),(255,255,0),(255,0,255),(0,255,255)]
    while l <= r and t <= b:
        for x in range(l, r + 1):
            pixels[index(x, t)] = random.choice(colors); pixels.show(); time.sleep(0.02)
        for y in range(t + 1, b + 1):
            pixels[index(r, y)] = random.choice(colors); pixels.show(); time.sleep(0.02)
        if t != b:
            for x in range(r - 1, l - 1, -1):
                pixels[index(x, b)] = random.choice(colors); pixels.show(); time.sleep(0.02)
        if l != r:
            for y in range(b - 1, t, -1):
                pixels[index(l, y)] = random.choice(colors); pixels.show(); time.sleep(0.02)
        l+=1; t+=1; r-=1; b-=1

def draw_smiley_face():
    clear()
    pattern = [
        [2, 3, 4, 5], [1, 6], [0, 2, 5, 7], [0, 7],
        [0, 2, 5, 7], [0, 3, 4, 7], [1, 6], [2, 3, 4, 5]
    ]
    for y, row in enumerate(pattern):
        for x in row:
            pixels[index(x, y)] = (255, 255, 0)
    pixels.show()

def run_animations():
    for _ in range(3):                     # shorter cycle
        light_specific_leds();     time.sleep(0.6)
        center_flash();            time.sleep(0.6)
        center_color_shift();      time.sleep(0.6)
        fast_scan();               time.sleep(0.6)
        gradual_fill();            time.sleep(0.6)
        swirl_out();               time.sleep(0.6)
        draw_smiley_face();        time.sleep(1.5)
    clear()

# ---------- HTTP assets ----------------------------------------------
with open("/templates/chapter3.html") as f:
    _BODY = f.read()

_PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
         f"Content-Length: {len(_BODY.encode())}\r\nConnection: close\r\n\r\n{_BODY}")

_STATIC = {
    b"/static/ch3_image.jpg":  ("image/jpeg",  "ch3_image.jpg"),
    b"/static/ch3_audio.opus": ("audio/mpeg",  "ch3_audio.opus"),
}

_BUF = bytearray(1024)
_RESP_204 = b"HTTP/1.1 204 No Content\r\n\r\n"

_ABORT_ERRS = {104, 32, 128}          # reset | pipe | not-connected

def _send_all(sock, data):
    if isinstance(data, str): data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try: sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in _ABORT_ERRS: return
            if e.errno == errno.EAGAIN: time.sleep(0.003)
            else: raise

# ---------- public entry point --------------------------------------
def try_handle(first: bytes, sock) -> bool:

    # 1) animation trigger
    if b"/run_animations" in first:
        _send_all(sock, _RESP_204)
        run_animations()
        return True

    # 2) static files
    for url,(mime,fname) in _STATIC.items():
        if url in first:
            _serve_file(fname, mime, sock)
            return True

    # 3) chapter page
    if first.startswith(b"GET /chapter3 "):
        _send_all(sock, _PAGE)
        return True

    return False

# ---------- file streamer -------------------------------------------
def _serve_file(fname, mime, sock):
    try:
        with open("/static/" + fname, "rb") as f:
            _send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
            while True:
                n = f.readinto(_BUF)
                if n == 0: break
                _send_all(sock, _BUF[:n])
    except Exception as e:
        print(fname, "err:", e)
        _send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")
