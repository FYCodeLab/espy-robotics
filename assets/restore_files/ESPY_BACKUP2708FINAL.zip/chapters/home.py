"""
home.py – serves the landing page at “/” with an image and a Start button
"""

import errno, time



_BUF = bytearray(1024)

# map URL  ➜  (MIME,  filename in /static )
_STATIC = {
    b"/static/home.jpg": ("image/jpeg", "home.jpg"),  # or .png – whatever you copy in
}

# ----------------------------------------------------------------------
def _send_all(sock, data):
    if isinstance(data, str):
        data = data.encode()
    mv, sent = memoryview(data), 0
    while sent < len(mv):
        try:
            sent += sock.send(mv[sent:])
        except OSError as e:
            if e.errno in (104, 32, 128):      # ECONNRESET, EPIPE
                return
            if e.errno == errno.EAGAIN:
                time.sleep(0.003)
            else:
                raise

# read the template once
with open("/templates/home.html") as f:
    _BODY = f.read()

_PAGE = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
         f"Content-Length: {len(_BODY.encode())}\r\nConnection: close\r\n\r\n{_BODY}")

_PING_RESP = b"HTTP/1.1 204 No Content\r\n\r\n"

def try_handle(first_line: bytes, sock) -> bool:
    # 0) ping
    if first_line.startswith(b"GET /ping "):
        _send_all(sock, _PING_RESP)
        return True
# ----------------------------------------------------------------------
def try_handle(first_line: bytes, sock) -> bool:
    """Return True iff this request was handled by the home page."""
    # 1) static image
    for url, (mime, fname) in _STATIC.items():
        if url in first_line:
            _serve_file(fname, mime, sock)
            return True

    # 2) the landing page ("/")
    if first_line.startswith(b"GET / ") or first_line.startswith(b"GET /index"):
       
        _send_all(sock, _PAGE)
        return True

    return False  # not for us

# ----------------------------------------------------------------------
def _serve_file(fname, mime, sock):
    try:
        with open("/static/" + fname, "rb") as f:
            _send_all(sock, f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\n\r\n")
            while True:
                n = f.readinto(_BUF)
                if n == 0:
                    break
                _send_all(sock, _BUF[:n])
    except Exception as e:
        print("home file err:", e)
        _send_all(sock, b"HTTP/1.1 404 Not Found\r\n\r\n")
