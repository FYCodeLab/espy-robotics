# for espy: # code.py
import main

#respirator :
#with open("/respirator/respirator.py") as f:
#    exec(f.read())

#8DOTS :
#with open("/8dots/strategy.py") as f:
#    exec(f.read())